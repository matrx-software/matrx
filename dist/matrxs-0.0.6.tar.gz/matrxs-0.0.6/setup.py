import setuptools


with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="matrxs",
    version="0.0.6",
    author="Jasper van der Waa",
    author_email="jasper.vanderwaa@tno.nl",
    description="A Python package for the rapid development of autonomous systems and human-agent teaming concepts.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://ci.tno.nl/gitlab/matrxs/matrxs",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)