

class TaskManager:

    def __init__(self):
        pass